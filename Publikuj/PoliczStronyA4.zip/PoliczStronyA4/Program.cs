﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;

namespace PoliczRozmiarStrony
{
    class Program
    {
        readonly string _dataPublikacji = "29 czerwca 2015";
        string _roboczyKatalog;
        readonly string _typPliku = "*.pdf";
        readonly Encoding _kodowanie;
        static List<string> _błędy = new List<string>();

        public Program(string roboczyKatalog, int stronaKodowa)
        {
            _kodowanie = Encoding.GetEncoding(stronaKodowa);
        }

        static void Main(string[] args)
        {
            if (args.Length == 0) { PoliczRozmiarStrony(); return; }
            var program = new Program(args[0], 1250);
            program.PokażLogo();
            string[] pliki = Directory.GetFiles(args[0], "*.pdf", SearchOption.AllDirectories);
            var liczbaPlików = 0;
            var sumaStron = 0;
            var sumaStronA4 = 0;
            var początek = DateTime.Now;
            using (StreamWriter writer = new StreamWriter("PoliczRozmiarStrony.txt", false, Encoding.GetEncoding(1250)))
            {
                //Nazwa pliku| Numer strony | Wysokość | Szerokość | Wysokość[cm] | Szerokość[cm] | Format arkusza | Liczba stron A4
                writer.WriteLine("Nazwa pliku\tNumer strony\tSzerokość\tWysokość\tSzerokość[cm]\tWysokość[cm]\tFormat arkusza\tLiczba stron A4");
                int nr = 1;
                foreach (var plik in pliki)
                {
                    PdfReader pdf = null;
                    try { pdf = new PdfReader(plik); }
                    catch (Exception ex) { _błędy.Add(plik + " (" + ex.Message + ")"); continue; } //Błędny plik
                    var liczbaStron = pdf.NumberOfPages;
                    var teraz = DateTime.Now;
                    var różnica = teraz - początek;
                    var sekundy = różnica.TotalSeconds;
                    var liczbaPlikówNaSekundę = nr / sekundy;
                    var przewidywanyCzas = (pliki.Length - nr) / liczbaPlikówNaSekundę;
                    Console.WriteLine("{0}, {1} stron[y] #{2}/{3} {4:F0}s {5:F0}pliki/s {6:F0}min. ({7})", plik, liczbaStron, 
                        nr++, pliki.Length, sekundy, liczbaPlikówNaSekundę, przewidywanyCzas / 60, _błędy.Count);
                    for (int strona = 1; strona <= liczbaStron; strona++)
                    {
                        Rectangle size = pdf.GetPageSize(strona);
                        var format = "A4";
                        //var stronyA4 = 1;
                        var szerokośćCm = size.Width * 0.3528;
                        var wysokośćCm = size.Height * 0.3528;
                        var stronyA4 = Math.Min(A4(szerokośćCm, wysokośćCm), A4(wysokośćCm, szerokośćCm));
                        if (stronyA4 > 8) format = "A0";
                        if (stronyA4 > 4) format = "A1";
                        if (stronyA4 > 2) format = "A2";
                        if (stronyA4 > 1) format = "A3";
                        else format = "A4";
                        writer.WriteLine("{0}\t{1}\t{2:F0}\t{3:F0}\t{4:F0}\t{5:F0}\t{6}\t{7}",
                            plik, strona, size.Width, size.Height, szerokośćCm, wysokośćCm, format, stronyA4);
                        sumaStronA4 += stronyA4;
                    }
                    sumaStron += liczbaStron;
                    liczbaPlików++;
                }
            }
            Console.WriteLine("Podsumowanie:");
            Console.WriteLine("Liczba plików: {0}", liczbaPlików);
            Console.WriteLine("Suma stron: {0}", sumaStron);
            Console.WriteLine("Suma stron A4: {0}", sumaStronA4);
            Console.WriteLine("Błędy: {0} (error.log)", _błędy.Count);
            File.WriteAllLines("error.log", _błędy);
            Console.WriteLine("Koniec.");
            Console.Read();
        }

        static void PoliczRozmiarStrony()
        {
            var linie = File.ReadAllLines("PoliczRozmiarStrony.txt", Encoding.GetEncoding(1250));
            var sumaStron = 0;
            var formaty = new Dictionary<string, int>();
            formaty.Add("A0", 0);
            formaty.Add("A1", 0);
            formaty.Add("A2", 0);
            formaty.Add("A3", 0);
            formaty.Add("A4", 0);
            var lines = new List<string>();
            foreach (var linia in linie.Skip(1))
            {
                var pola = linia.Split('\t');
                var szerokość = double.Parse(pola[4]);
                var wysokość = double.Parse(pola[5]);
                var max = Math.Max(szerokość, wysokość);
                var format = "A4";
                var stronyA4 = 1;
                /*if (max > 1180.0) { format = "A0"; stronyA4 = 16; }
                else if (max > 840.0) { format = "A1"; stronyA4 = 8; }
                else if (max > 590.0) { format = "A2"; stronyA4 = 4; }
                else if (max > 400.0) { format = "A3"; stronyA4 = 2; }
                else if (max > 290.0) { format = "A4"; stronyA4 = 1; }
                else { format = "A4"; stronyA4 = 1; }*/
                var doA4 = OdległośćDoA4(szerokość, wysokość);
                var doA3 = OdległośćDoA3(szerokość, wysokość);
                var doA2 = OdległośćDoA2(szerokość, wysokość);
                var doA1 = OdległośćDoA1(szerokość, wysokość);
                var doA0 = OdległośćDoA0(szerokość, wysokość);
                var min = doA0;
                format = "A0";
                stronyA4 = 16;
                if (min > doA1) { format = "A1"; stronyA4 = 8; min = doA1; }
                if (min > doA2) { format = "A2"; stronyA4 = 4; min = doA2; }
                if (min > doA3) { format = "A3"; stronyA4 = 2; min = doA3; }
                if (min > doA4) { format = "A4"; stronyA4 = 1; min = doA4; }
                sumaStron += stronyA4;
                formaty[format]++;
                lines.Add(string.Format("{0:F0}\t{1:F0} {2} {3} {4} {5} {6}", 
                    Math.Max(szerokość, wysokość), Math.Min(szerokość, wysokość),
                    doA0, doA1, doA2, doA3, doA4));
            }
            File.WriteAllLines("PoliczRozmiarStronyA4.csv", lines, Encoding.GetEncoding(1250));
            Console.WriteLine("Suma stron: {0}", linie.Length - 1);
            Console.WriteLine("Suma stron A4: {0}", sumaStron);
            Console.WriteLine("Stron[y] formatu A0: {0}", formaty["A0"]);
            Console.WriteLine("Stron[y] formatu A1: {0}", formaty["A1"]);
            Console.WriteLine("Stron[y] formatu A2: {0}", formaty["A2"]);
            Console.WriteLine("Stron[y] formatu A3: {0}", formaty["A3"]);
            Console.WriteLine("Stron[y] formatu A4: {0}", formaty["A4"]);
            Console.WriteLine("Koniec.");
            Console.Read();
        }

        static double OdległośćDoA0(double szerokość, double wysokość) { return Odległość(szerokość, wysokość, 840, 1192); }
        static double OdległośćDoA1(double szerokość, double wysokość) { return Odległość(szerokość, wysokość, 594, 840); }
        static double OdległośćDoA2(double szerokość, double wysokość) { return Odległość(szerokość, wysokość, 420, 594); }
        static double OdległośćDoA3(double szerokość, double wysokość) { return Odległość(szerokość, wysokość, 297, 420); }
        static double OdległośćDoA4(double szerokość, double wysokość) { return Odległość(szerokość, wysokość, 210, 297); }

        static double Odległość(double szerokość, double wysokość, double szerokośćA, double wysokośćA)
        {
            //Połóż na dłuższym boku
            var dłuższy = Math.Max(szerokość, wysokość);
            var krótszy = Math.Min(szerokość, wysokość);
            //Połóż na dłuższym boku
            var dłuższyA = Math.Max(szerokośćA, wysokośćA);
            var krótszyA = Math.Min(szerokośćA, wysokośćA);
            //Oblicz odległość
            var dłuższyRóżnica = dłuższy - dłuższyA;
            var krótszyRóżnica = krótszy - krótszyA;
            return dłuższyRóżnica * dłuższyRóżnica + krótszyRóżnica * krótszyRóżnica;
        }

        static int A4(double szerokość, double wysokość)
        {
            var a4 = 0;
            var szerokośćA4 = 210.0 + 42.0; //+42 (20%)
            var wysokośćA4 = 297.0 + 60.0; //+60 (20%)
            //A4 210×297 (w x h)
            //A3 297x420 (h x 2*w)
            //A2 420x594 (2*w x 2*h)
            var s = (int)Math.Ceiling(szerokość / szerokośćA4);
            var w = (int)Math.Ceiling(wysokość / wysokośćA4);
            a4 = s * w;
            return a4;
        }


        void PokażLogo()
        {
            Console.WriteLine("PoliczRozmiarStrony v1.2 - Policz rozmiar stron w plikach pdf");
            Console.WriteLine("Data publikacji: {0}", _dataPublikacji);
            Console.WriteLine("Roboczy katalog: {0}", _roboczyKatalog);
        }

        void WyszukajPliki()
        {
            Console.Write("Pliki *.pdf: {0}", 0);
            var pliki = Directory.GetFiles(_roboczyKatalog, "*.pdf", SearchOption.AllDirectories);
            Console.WriteLine(pliki.Length);
        }
    }
}
